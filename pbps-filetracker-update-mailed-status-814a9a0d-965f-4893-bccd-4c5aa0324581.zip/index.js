
const aws = require('aws-sdk');
const s3 = new aws.S3();
const logHelper = require('./loghelper');
const { executeMySqlFileTrackerAsync, initializePool } = require('./executeMySqlFileTracker');

exports.handler = async (event) => {
  let params = {};
  let fileKey = '';
  let pool = '';
  try {
    const bucket = event.Records[0].s3.bucket.name;
    fileKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    pool = initializePool(bucket);
    params = {
      Bucket: bucket,
      Key: fileKey,
    };
    const file = s3.getObject(params).promise();
    if(file && file.Body){
      const mailedStatusFileContent = file.Body.toString('utf-8').trim();
      let mailedStatusJson = [];
      const updatedBy = 'IXT - Mail Poller';
      if (mailedStatusFileContent) {
        const batches = mailedStatusFileContent.split('\n');
        if (batches) {
          const mailedList = batches.map(batch => {
            const batchinfo = batch.split('|');
            let mail = new Date((batchinfo[4] || null).trim());
            if (batchinfo.length >= 5) {
              return {
                systemId: isNaN(batchinfo[0]) ? 0 : parseInt(batchinfo[0]),
                batchId: isNaN(batchinfo[1]) ? 0 : parseInt(batchinfo[1]),
                status: batchinfo[3] || '',
                statusdate: mail.toISOString().slice(0, 19).replace('T', ' '),
              };
            }
          });
          mailedStatusJson = mailedList.filter(data => data);
        } else {
          throw new Error("No batch found");
        }
      }
      const param = [JSON.stringify(mailedStatusJson), updatedBy];
      const result = await executeMySqlFileTrackerAsync("call update_mailed_status(?,?)", param, pool);
      var copyParams = {
        CopySource: bucket + '/' + fileKey,
        Bucket: bucket,
        Key: fileKey.replace('file-tracker/', 'file-tracker-archive/'),
      };

      await s3.copyObject(copyParams).promise();
      await s3.deleteObject(params).promise;
      console.log({
        fileKey,
        message: result[0][0].message
      });
      return {
        fileKey,
        message: result[0][0].message
      };
    }
    return {"error": "file not found"};
    
  } catch (err) {
    logHelper.logMajorError(err, fileKey, 'fileTracking - update Mailed status', JSON.stringify(params));
    return err;
  } finally {
    if (pool) {
      pool.end();
    }
  }
};
