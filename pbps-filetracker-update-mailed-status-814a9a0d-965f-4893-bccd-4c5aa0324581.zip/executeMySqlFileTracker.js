const Promise = require('bluebird');
const mysql = require('mysql');

Promise.promisifyAll(mysql);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);
Promise.promisifyAll(require("mysql/lib/Connection").prototype);

const initializePool = (bucketName) => {
    
    let pool;
    switch (bucketName) {
        case 'pbps-chc-dev-print':
            pool = mysql.createPool({
                connectionLimit: 100,
                host: "pbps-filetracker-qa-instance-1.cqj2zsuhebsa.us-east-1.rds.amazonaws.com",
                port: 3306,
                database: "FileTracking",
                user: "csspadmin",
                password: "MR5Nd!7mWIyvcL98=M",
                multipleStatements: true
            });
            break;
        case 'pbps-chc-qa-print':
            pool = mysql.createPool({
                connectionLimit: 100,
                host: "pbps-filetracker-qa-instance-1.cqj2zsuhebsa.us-east-1.rds.amazonaws.com",
                port: 3306,
                database: "FileTracking",
                user: "csspadmin",
                password: "MR5Nd!7mWIyvcL98=M",
                multipleStatements: true
            });
            break;
        case 'pbps-chc-cert-print':
            pool = mysql.createPool({
                connectionLimit: 100,
                host: "pbps-filetracker-cert.cluster-cqj2zsuhebsa.us-east-1.rds.amazonaws.com",
                port: 3306,
                database: "FileTracking",
                user: "csspadmin",
                password: "MR5Nd!7mWIyvcL98=M",
                multipleStatements: true
            });
            break;
        case 'pbps-chc-prod-print':
            pool = mysql.createPool({
                connectionLimit: 100,
                host: "pbps-ct-filetracking.ccv4rzmtjxrf.us-east-1.rds.amazonaws.com",
                port: 3306,
                database: "FileTracking",
                user: "csspadmin",
                password: "MR5Nd!7mWIyvcL98=M",
                multipleStatements: true
            });
            break;
        default:
            pool = mysql.createPool({
                connectionLimit: 100,
                host: "pbps-filetracker-qa-instance-1.cqj2zsuhebsa.us-east-1.rds.amazonaws.com",
                port: 3306,
                database: "FileTracking",
                user: "csspadmin",
                password: "MR5Nd!7mWIyvcL98=M",
                multipleStatements: true
            });
    }
    return pool;
};

function executeMySqlFileTracker(sql, params, callback, pool) {
    try {
        pool.getConnection(function (err, connection) {
            try{
                if (err) {
                    callback(err);
                }
                connection.query(sql, params, function (err, result) {
                    if (err) {
                        callback(err);
                    } else {
                        callback(null, result);
                    }
                });
            }catch(e){
                callback(e);
            }finally{
                connection.destroy();
            }
        });
    } catch (e) {
        callback(e);
    }
}

async function executeMySqlFileTrackerAsync(sql, params, pool) {
    let conn;
    try {
      conn = await pool.getConnectionAsync();
      const result = await conn.queryAsync(sql, params);
      return result;
    } catch (e) {
      // eslint-disable-next-line no-console
      console.log(e);
      throw new Error(`Exception: ${e}`);
    } finally {
      if (conn) {
        conn.destroy();
      }
    }
 }
module.exports = { executeMySqlFileTracker, initializePool, executeMySqlFileTrackerAsync };