var AWS = require('aws-sdk');
var lambda = new AWS.Lambda({region:"us-east-1"});
const fs = require('fs');
const { executeMySqlFileTracker } = require('./executeMySqlFileTracker');

// severity -> 1:minor, 2:medium, 3:major
function writeToDb(severity, message, methodName, inputParameters,
    logType = 'Error', fileName = null, updatedby = 'File Tracker Lambda', referencenumber = null) {
    try {
        if (logType === 'Error') {
            console.log(message);
        }
        const param = [logType, 'AWS Lambda', parseInt(severity), message, updatedby, referencenumber,
            methodName, inputParameters];
        executeMySqlFileTracker('call insert_system_log(?,?,?,?,?,?,?,?)', param, (err) => {
            if (err) {
                console.log(err);
            }
        });
    } catch (e) {
        console.log(e);
    }
}

function getMessage(error) {
    let returnMsg = error.toString();
    if (error.stack) {
        returnMsg += `\n${error.stack}`;
    }
    return returnMsg;
}

const logHelper = {
    logMinorError: (error, fileName = null, methodName = '', inputParameters = '') => {
        let message = getMessage(error);
        writeToDb(1, message, methodName, inputParameters, 'Error', fileName);
    },
    logMediumError: (error, fileName = null, methodName = '', inputParameters = '') => {
        let message = getMessage(error);
        writeToDb(2, message, methodName, inputParameters, 'Error', fileName);
    },
    logMajorError: (error, fileName = null, methodName = '', inputParameters = '') => {
        let message = getMessage(error);
        writeToDb(3, message, methodName, inputParameters, 'Error', fileName);
    },
    // severity -> 1:minor, 2:medium, 3:major
    logError: (severity, error, fileName = null, methodName = '', inputParameters = '') => {
        let message = getMessage(error);
        writeToDb(severity, message, methodName, inputParameters, 'Error', fileName);
    },
    logInfo: (message, methodName = '', inputParameters = '') => {
        writeToDb(1, message, methodName, inputParameters, 'Info');
    },
    logDebugInfo: (message, methodName = '', inputParameters = '') => {
        writeToDb(1, message, methodName, inputParameters, 'Debug');
    },
};

module.exports = logHelper;